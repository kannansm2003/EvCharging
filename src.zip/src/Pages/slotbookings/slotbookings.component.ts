import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { SlotAvailableService } from '../../app/services/slot-available.service';
import { BookingServiceService } from '../../app/services/booking-service.service';

interface Slot {
    slotNo: string | number;
    status: string;
    chargerId: number;
}
@Component({
  selector: 'app-slotbookings',
  imports: [FormsModule, CommonModule, ReactiveFormsModule],
  templateUrl: './slotbookings.component.html',
  styleUrl: './slotbookings.component.css'
})
export class SlotbookingsComponent implements OnInit {
    stationId: string | null = null;
    availableChargers: { chargerId: number; type: string }[] = [];
    slotsByCharger: Map<number, Slot[]> = new Map(); 
    selectedSlot: number | null = null;
    selectedCharger: { chargerId: number; type: string } | null = null;
    constructor(private readonly router: Router, 
        private readonly slotAvailableService: SlotAvailableService,
        private readonly bookingService:BookingServiceService
    ) {}
  
    ngOnInit(): void {
        if (typeof window !== 'undefined') {
            this.stationId = localStorage.getItem('stationId');
            console.log("ngOnInit -> Station ID:", this.stationId);
            this.fetchAvailableChargers();
        } 
    }
    
    fetchAvailableChargers() {
      if (this.stationId) {
        const stationIdNumber = parseInt(this.stationId, 10);
        this.slotAvailableService.getAvailableChargers(stationIdNumber).subscribe({
          next: (chargers: any[]) => {
            console.log("API Response for chargers:", chargers);
            if (Array.isArray(chargers)) {
              this.availableChargers = chargers.map(charger => ({
                chargerId: charger.id,
                type: 'Unknown' 
              }));
              this.availableChargers.forEach(charger => this.fetchAvailableSlots(charger.chargerId));
            } else {
              console.error('chargers is not an array', chargers);
            }
          },
          error: (error) => console.error('Error fetching available chargers:', error)
        });
      } else {
        console.error('Station ID not found in local storage');
      }
    }
  
    fetchAvailableSlots(chargerId: number): void {
      this.slotAvailableService.getAvailableSlots(chargerId).subscribe({
        next: (availableSlots) => {
          const totalSlots = 24;
          const allSlots = Array.from({ length: totalSlots }, (_, i) => i + 1);
          const availableSlotNumbers = new Set(availableSlots);
          const slots = allSlots.map(slotNo => ({
            slotNo: slotNo,
            status: availableSlotNumbers.has(slotNo) ? "available" : "booked",
            chargerId: chargerId
          }));
          this.slotsByCharger.set(chargerId, slots);
          console.log(`Processed slots for Charger ${chargerId}:`, slots);
        },
        error: (error) => console.error(`Error fetching slots for Charger ${chargerId}:`, error)
      });
    }
  
    getSlotsForCharger(chargerId: number) {
      return this.slotsByCharger.get(chargerId) || []; 
    }
  
    getAvailableSlotCount(chargerId: number) {
      return this.getSlotsForCharger(chargerId).filter(slot => slot.status === 'available').length;
    }
  
    handleSlotClick(slot: any, charger: any): void {
        if (slot.status === 'available') {
          this.selectedSlot = slot.slotNo;
          this.selectedCharger = charger;
          this.bookSlot(); 
        }
      }

      bookSlot(): void {
        const userId = parseInt(localStorage.getItem('userId') ?? '0', 10);
        if (this.stationId && this.selectedSlot !== null && this.selectedCharger) {
            const stationIdNumber = parseInt(this.stationId, 10);
            console.log('Booking with Charger ID:', this.selectedCharger.chargerId);
      
            this.bookingService.placeBooking(stationIdNumber, this.selectedCharger.chargerId, this.selectedSlot, userId).subscribe({
                next: (response) => {
                    console.log('Booking successful:', response);
                    this.fetchAvailableSlots(this.selectedCharger?.chargerId ?? 0);
                    this.router.navigate(['/payment']);
                },
                error: (error) => {
                    console.error('Error placing booking:', error);
                }
            });
        }
    }
}
  