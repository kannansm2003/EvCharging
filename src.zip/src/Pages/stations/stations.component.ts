import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { StationService } from '../../app/services/stations.service';

@Component({
  selector: 'app-stations',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterLink],
  templateUrl: './stations.component.html',
  styleUrls: ['./stations.component.css']
})
export class StationsComponent implements OnInit {
  latitude: number | undefined;
  longitude: number | undefined;
  errorMessage: string | undefined;
  chargingStations: any[] = [];

  constructor(private readonly stationService: StationService) {}

  ngOnInit(): void {
    this.getLocation();
  }

  getLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          this.latitude = position.coords.latitude;
          this.longitude = position.coords.longitude;
          console.log(`Latitude: ${this.latitude}, Longitude: ${this.longitude}`);
          this.getNearestStations();
        },
        (error) => {
          this.errorMessage = `Error getting location: ${error.message}`;
          console.error(this.errorMessage);
        }
      );
    } else {
      this.errorMessage = 'Geolocation is not supported by this browser.';
      console.error(this.errorMessage);
    }
  }

  getNearestStations() {
    if (this.latitude && this.longitude) {
      this.stationService.getNearestStations(this.latitude, this.longitude).subscribe({
        next: (response) => {
          console.log('Nearest charging stations:', response);
          this.chargingStations = response;
        },
        error: (error) => {
          console.error('Error fetching charging stations:', error);
          this.errorMessage = 'Failed to load charging stations.';
        } 
      });
    }
  }
}