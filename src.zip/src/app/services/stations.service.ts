import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root' // Makes this service available throughout the app
})
export class StationService {
  private readonly apiUrl = 'http://localhost:8090/api/v1/charging_stations/nearest';

  constructor(private readonly http: HttpClient) {}

  // Fetch the nearest charging stations based on user location
  getNearestStations(latitude: number, longitude: number): Observable<any[]> {
    const url = `${this.apiUrl}?latitude=${latitude}&longitude=${longitude}`;
    return this.http.get<any[]>(url);
  }
}
