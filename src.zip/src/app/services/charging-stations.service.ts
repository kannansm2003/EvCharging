import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ChargingStationService {
  private readonly apiUrl = 'http://localhost:8090/api/v1/charging_stations';

  constructor(private readonly http: HttpClient) {}

  getStationDetails(stationId: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/${stationId}`);
  }

  getAllStations(): Observable<any> {
    return this.http.get(this.apiUrl);
  }
}
