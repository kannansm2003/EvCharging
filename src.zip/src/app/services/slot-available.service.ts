import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SlotAvailableService {
  private readonly baseUrl = 'http://localhost:8090/api/v1';

  constructor(private readonly http: HttpClient) {}

  getAvailableChargers(stationId: number): Observable<{ chargerId: number; type: string }[]> {
    return this.http.get<{ chargerId: number; type: string }[]>(`${this.baseUrl}/charger/byStation/${stationId}`);
  }

  getAvailableSlots(chargerId: number): Observable<number[]> {
    return this.http.get<number[]>(`${this.baseUrl}/bookings/availableSlots/${chargerId}`);
  }
}