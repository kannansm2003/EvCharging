import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {
  private readonly apiUrl='http://localhost:8090/api/v1/user/login';
  constructor(private readonly http:HttpClient) { }
  login(username: string, password: string): Observable<any> {
    const url = `${this.apiUrl}`;
    return this.http.post(url, { username, password }, { responseType: 'json' });


  
}
}
